/**
 * 
 */
package com.djh.sbm.util;

/**
 * @author admin
 * 2017年11月17日
 */
public class Constant {
	
	public static final String FILE_USER_PHOTO_PATH = "files/user/pic/photo/";
}
